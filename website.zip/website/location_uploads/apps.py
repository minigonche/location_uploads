from django.apps import AppConfig


class LocationUploadsConfig(AppConfig):
    name = 'location_uploads'
